Cloud Foundry Genesis Kit
==================

This is a Genesis Kit for the [Cloud Foundry][1].

To use it, you don't even need to clone this repository!  Just run
the following (using Genesis v2):

```
genesis init --kit cf my-cf-deployments
```

Ta da!

[1]: https://docs.cloudfoundry.org
